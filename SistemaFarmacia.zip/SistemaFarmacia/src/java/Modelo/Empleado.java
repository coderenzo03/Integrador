package Modelo;

public class Empleado {
    private int idEmpleado;
    private String dni;
    private String nombres;
    private String tel;
    private String estado;
    private String user;
    private String password; // Agregar campo para la contraseña

    // Getters y Setters
    public int getIdEmpleado() {
        return idEmpleado;
    }

    public void setIdEmpleado(int idEmpleado) {
        this.idEmpleado = idEmpleado;
    }

    public String getDni() {
        return dni;
    }

    public void setDni(String dni) {
        this.dni = dni;
    }

    public String getNombres() {
        return nombres;
    }

    public void setNombres(String nombres) {
        this.nombres = nombres;
    }

    public String getTel() {
        return tel;
    }

    public void setTel(String tel) {
        this.tel = tel;
    }

    public String getEstado() {
        return estado;
    }

    public void setEstado(String estado) {
        this.estado = estado;
    }

    public String getUser() {
        return user;
    }

    public void setUser(String user) {
        this.user = user;
    }

    public String getPassword() { // Getter para la contraseña
        return password;
    }

    public void setPassword(String password) { // Setter para la contraseña
        this.password = password;
    }
}
