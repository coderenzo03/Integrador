package Modelo;

import config.Conexion;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class ClienteDAO {
    // Cambié las variables de instancia a privadas y las inicialicé solo en los métodos
    // para evitar posibles problemas de concurrencia
    private Connection cx;

    // Método para buscar un cliente por DNI
    public Clientes buscar(String dni) {
        Clientes c = null; // Inicializar como null
        String sql = "SELECT * FROM cliente WHERE dni = ?"; // Usar un placeholder

        try (Connection cx = Conexion.getConection(); 
             PreparedStatement ps = cx.prepareStatement(sql)) {
            
            ps.setString(1, dni);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) { // Solo buscar uno
                    c = new Clientes();
                    c.setIdCliente(rs.getInt("idCliente")); // Usar nombre de columna
                    c.setDni(rs.getString("dni"));
                    c.setNombres(rs.getString("nombres"));
                    c.setDireccion(rs.getString("direccion"));
                    c.setEstado(rs.getString("estado"));
                }
            }
        } catch (SQLException e) {
            e.printStackTrace(); // Manejo de errores específico
        }
        return c;
    }

    // Método para listar todos los clientes
    public List<Clientes> listar() {
        String sql = "SELECT * FROM cliente";
        List<Clientes> lista = new ArrayList<>();

        try (Connection cx = Conexion.getConection(); 
             PreparedStatement ps = cx.prepareStatement(sql); 
             ResultSet rs = ps.executeQuery()) {
            
            while (rs.next()) {
                Clientes cl = new Clientes();
                cl.setIdCliente(rs.getInt("idCliente")); // Usar nombre de columna
                cl.setDni(rs.getString("dni"));
                cl.setNombres(rs.getString("nombres"));
                cl.setDireccion(rs.getString("direccion"));
                cl.setEstado(rs.getString("estado"));
                lista.add(cl);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return lista;
    }

    // Método para agregar un nuevo cliente
    public int agregar(Clientes cl) {
        String sql = "INSERT INTO cliente (dni, nombres, direccion, estado) VALUES (?, ?, ?, ?)";
        int r = 0;

        try (Connection cx = Conexion.getConection(); 
             PreparedStatement ps = cx.prepareStatement(sql)) {
            
            ps.setString(1, cl.getDni());
            ps.setString(2, cl.getNombres());
            ps.setString(3, cl.getDireccion());
            ps.setString(4, cl.getEstado());
            r = ps.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return r;
    }

    // Método para actualizar un cliente existente
    public int actualizar(Clientes cl) {
        String sql = "UPDATE cliente SET dni=?, nombres=?, direccion=?, estado=? WHERE idCliente=?";
        int r = 0;

        try (Connection cx = Conexion.getConection(); 
             PreparedStatement ps = cx.prepareStatement(sql)) {
            
            ps.setString(1, cl.getDni());
            ps.setString(2, cl.getNombres());
            ps.setString(3, cl.getDireccion());
            ps.setString(4, cl.getEstado());
            ps.setInt(5, cl.getIdCliente());
            r = ps.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return r;
    }

    // Método para eliminar un cliente por ID
    public void eliminar(int id) {
        String sql = "DELETE FROM cliente WHERE idCliente=?";
        
        try (Connection cx = Conexion.getConection(); 
             PreparedStatement ps = cx.prepareStatement(sql)) {
            
            ps.setInt(1, id);
            ps.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public Clientes buscarCliente(String dniClienteBuscado) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
}
