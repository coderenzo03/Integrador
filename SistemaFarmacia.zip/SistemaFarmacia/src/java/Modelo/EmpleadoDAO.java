package Modelo;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import config.Conexion;
import java.util.ArrayList;
import java.util.List;

public class EmpleadoDAO {

    private PreparedStatement ps;
    private ResultSet rs;
    private Connection cx;

    // Método para validar el empleado
    public Empleado validar(String usuario, String contraseña) {
        Empleado em = null;
        String sql = "SELECT * FROM empleado WHERE User = ? AND Password = ?";

        try {
            cx = Conexion.getConection();
            ps = cx.prepareStatement(sql);
            ps.setString(1, usuario);
            ps.setString(2, contraseña);
            rs = ps.executeQuery();

            if (rs.next()) {
                em = new Empleado();
                em.setIdEmpleado(rs.getInt("IdEmpleado"));
                em.setDni(rs.getString("Dni"));
                em.setNombres(rs.getString("Nombres"));
                em.setUser(rs.getString("User"));
                // No incluyas la contraseña en el objeto si no es necesario
            }
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            closeResources(); // Asegúrate de cerrar los recursos adecuadamente
        }
        return em;
    }

    // Método para listar todos los empleados
    public List<Empleado> listar() {
        String sql = "SELECT * FROM empleado";
        List<Empleado> lista = new ArrayList<>();
        try {
            cx = Conexion.getConection();
            ps = cx.prepareStatement(sql);
            rs = ps.executeQuery();
            while (rs.next()) {
                Empleado em = new Empleado();
                em.setIdEmpleado(rs.getInt("idEmpleado"));
                em.setDni(rs.getString("Dni"));
                em.setNombres(rs.getString("Nombres"));
                em.setTel(rs.getString("Telefono")); // Corregir el campo de nombre
                em.setEstado(rs.getString("Estado"));
                em.setUser(rs.getString("User"));
                // Agregar más atributos si es necesario
                lista.add(em);
            }
        } catch (SQLException e) {
            e.printStackTrace(); // Manejo de la excepción
        } finally {
            closeResources();
        }
        return lista;
    }

    // Método para agregar un empleado
    public int agregar(Empleado em) {
        String sql = "INSERT INTO empleado(Dni, Nombres, Telefono, Estado, User, Password) VALUES(?, ?, ?, ?, ?, ?)";
        int r = 0;
        try {
            cx = Conexion.getConection();
            ps = cx.prepareStatement(sql);
            ps.setString(1, em.getDni());
            ps.setString(2, em.getNombres());
            ps.setString(3, em.getTel());
            ps.setString(4, em.getEstado());
            ps.setString(5, em.getUser());
            ps.setString(6, em.getPassword()); // Agregar contraseña
            r = ps.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace(); // Manejo de la excepción
        } finally {
            closeResources();
        }
        return r;
    }

    // Método para listar un empleado por ID
    public Empleado listarId(int id) {
        Empleado emp = new Empleado();
        String sql = "SELECT * FROM empleado WHERE idEmpleado=?";
        try {
            cx = Conexion.getConection();
            ps = cx.prepareStatement(sql);
            ps.setInt(1, id);
            rs = ps.executeQuery();

            if (rs.next()) {
                emp.setIdEmpleado(rs.getInt("idEmpleado")); // Asegúrate de que se agrega ID
                emp.setDni(rs.getString("Dni"));
                emp.setNombres(rs.getString("Nombres"));
                emp.setTel(rs.getString("Telefono"));
                emp.setEstado(rs.getString("Estado"));
                emp.setUser(rs.getString("User"));
                emp.setPassword(rs.getString("Password")); // Agregar el atributo de contraseña
            }
        } catch (SQLException e) {
            e.printStackTrace(); // Manejo de la excepción
        } finally {
            closeResources();
        }
        return emp;
    }

    // Método para actualizar un empleado existente
    public int actualizar(Empleado em) {
        String sql = "UPDATE empleado SET Dni=?, Nombres=?, Telefono=?, Estado=?, User=?, Password=? WHERE idEmpleado=?";
        int r = 0;
        try {
            cx = Conexion.getConection();
            ps = cx.prepareStatement(sql);
            ps.setString(1, em.getDni());
            ps.setString(2, em.getNombres());
            ps.setString(3, em.getTel());
            ps.setString(4, em.getEstado());
            ps.setString(5, em.getUser());
            ps.setString(6, em.getPassword()); // Asegúrate de actualizar también la contraseña
            ps.setInt(7, em.getIdEmpleado());
            r = ps.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace(); // Manejo de la excepción
        } finally {
            closeResources();
        }
        return r;
    }

    // Método para eliminar un empleado por ID
    public void delete(int id) {
        String sql = "DELETE FROM empleado WHERE idEmpleado=?";
        try {
            cx = Conexion.getConection();
            ps = cx.prepareStatement(sql);
            ps.setInt(1, id);
            ps.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace(); // Manejo de la excepción
        } finally {
            closeResources();
        }
    }

    // Método para cambiar la contraseña de un empleado
    public int cambiarContrasena(int idEmpleado, String nuevaContrasena) {
        String sql = "UPDATE empleado SET Password=? WHERE idEmpleado=?";
        int r = 0;
        try {
            cx = Conexion.getConection();
            ps = cx.prepareStatement(sql);
            ps.setString(1, nuevaContrasena); // Nueva contraseña
            ps.setInt(2, idEmpleado); // ID del empleado
            r = ps.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace(); // Manejo de la excepción
        } finally {
            closeResources();
        }
        return r;
    }

    // Método para cerrar recursos
    private void closeResources() {
        try {
            if (rs != null) {
                rs.close();
            }
            if (ps != null) {
                ps.close();
            }
            if (cx != null) {
                cx.close();
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void eliminar(int ide) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

}
