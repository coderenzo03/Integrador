package Modelo;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import config.Conexion;
import java.util.List;

public class VentaDAO {
    private PreparedStatement ps;
    private ResultSet rs;
    private Connection cx;

    // Método para generar el número de serie
    public String generarSerie() {
        String numeroSerie = ""; // Valor predeterminado
        String sql = "SELECT MAX(NumeroSerie) FROM ventas";

        try {
            cx = Conexion.getConection();
            ps = cx.prepareStatement(sql);
            rs = ps.executeQuery();
            if (rs.next()) {
                numeroSerie = rs.getString(1);
            }
        } catch (SQLException e) {
            e.printStackTrace(); // Manejo de la excepción
        } finally {
            closeResources();
        }
        return numeroSerie;
    }

    // Método para obtener el ID de ventas
    public String idVentas() {
        String idVentas = "";
        String sql = "SELECT MAX(IdVentas) FROM ventas";

        try {
            cx = Conexion.getConection();
            ps = cx.prepareStatement(sql);
            rs = ps.executeQuery();
            if (rs.next()) {
                idVentas = rs.getString(1);
            }
        } catch (SQLException e) {
            e.printStackTrace(); // Manejo de la excepción
        } finally {
            closeResources();
        }
        return idVentas;
    }

    // Método para guardar una venta
    public int guardarVenta(Venta ve) {
        String sql = "INSERT INTO ventas (IdCliente, IdEmpleado, NumeroSerie, FechaVentas, Monto, Estado) VALUES (?, ?, ?, ?, ?, ?)";
        int r = 0;

        try {
            cx = Conexion.getConection();
            ps = cx.prepareStatement(sql);
            ps.setInt(1, ve.getIdCliente());
            ps.setInt(2, ve.getIdEmpleado());
            ps.setString(3, ve.getNumSerie());
            ps.setString(4, ve.getFecha());
            ps.setDouble(5, ve.getMonto()); // Se debe usar monto en vez de precio
            ps.setString(6, ve.getEstado());
            r = ps.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace(); // Manejo de la excepción
        } finally {
            closeResources();
        }

        return r;
    }

    // Método para guardar detalles de ventas
    public int guardarDetalleVentas(Venta venta) {
        String sql = "INSERT INTO detalle_ventas (IdVentas, IdProducto, cantidad, PrecioVenta) VALUES (?, ?, ?, ?)";
        int r = 0;

        try {
            cx = Conexion.getConection();
            ps = cx.prepareStatement(sql);
            ps.setInt(1, venta.getId()); // Asegúrate de que este ID sea correcto
            ps.setInt(2, venta.getIdProducto());
            ps.setInt(3, venta.getCantidad());
            ps.setDouble(4, venta.getPrecio());
            r = ps.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace(); // Manejo de la excepción
        } finally {
            closeResources();
        }

        return r;
    }

    // Método para cerrar recursos
    private void closeResources() {
        try {
            if (rs != null) rs.close();
            if (ps != null) ps.close();
            if (cx != null) cx.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public String IdVentas() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    public void guardarDetalleventas(Venta v) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    public String GenerarSerie() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    public void registrarVenta(Venta nuevaVenta, List<Venta> listaVentas) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    public void generar(Venta v) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
}
