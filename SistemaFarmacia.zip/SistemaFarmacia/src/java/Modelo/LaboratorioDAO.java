package Modelo;

import config.Conexion;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class LaboratorioDAO {

    // Método para registrar un laboratorio
    public boolean registrar(Laboratorio lab) {
        String sql = "INSERT INTO laboratorio (RUC, nombre, telefono, direccion) VALUES (?, ?, ?, ?)";
        try (Connection con = Conexion.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setString(1, lab.getRUC());
            ps.setString(2, lab.getNombre());
            ps.setString(3, lab.getTelefono());
            ps.setString(4, lab.getDireccion());
            return ps.executeUpdate() > 0; // Retorna true si se insertó correctamente
        } catch (SQLException e) {
            e.printStackTrace(); // Imprime el error en consola
            return false;
        }
    }

    // Método para listar todos los laboratorios
    public List<Laboratorio> listar() {
        List<Laboratorio> laboratorios = new ArrayList<>();
        String sql = "SELECT * FROM laboratorio"; // Ajusta la consulta según tu base de datos
        try (Connection con = Conexion.getConnection();
             PreparedStatement ps = con.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {

            while (rs.next()) {
                Laboratorio lab = new Laboratorio();
                lab.setIdLaboratorio(rs.getInt("idLaboratorio"));
                lab.setRUC(rs.getString("RUC"));
                lab.setNombre(rs.getString("nombre"));
                lab.setTelefono(rs.getString("telefono"));
                lab.setDireccion(rs.getString("direccion"));
                laboratorios.add(lab);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return laboratorios;
    }

    public void agregar(Laboratorio lab) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
}
