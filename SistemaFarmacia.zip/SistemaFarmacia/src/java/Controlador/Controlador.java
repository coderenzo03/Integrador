package Controlador;

import Modelo.Clientes;
import Modelo.ClienteDAO;
import Modelo.Empleado;
import Modelo.EmpleadoDAO;
import Modelo.Laboratorio;
import Modelo.LaboratorioDAO;
import Modelo.Producto;
import Modelo.ProductoDAO;
import Modelo.Venta;
import Modelo.VentaDAO;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.List;

@WebServlet(name = "Controlador", urlPatterns = {"/Controlador"})
public class Controlador extends HttpServlet {

    private static final long serialVersionUID = 1L;
    private EmpleadoDAO edao = new EmpleadoDAO();
    private ClienteDAO cdao = new ClienteDAO();
    private ProductoDAO pdao = new ProductoDAO();
    private VentaDAO vdao = new VentaDAO();
    private LaboratorioDAO labdao = new LaboratorioDAO(); // Añadido para Laboratorio

    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String menu = request.getParameter("menu");
        String accion = request.getParameter("accion");

        if (menu == null) {
            response.sendError(HttpServletResponse.SC_BAD_REQUEST, "El parámetro 'menu' es requerido.");
            return;
        }
        switch (menu) {
            case "Login":
                iniciarSesion(request, response);
                break;

            case "Principal":
                mostrarPrincipal(request, response);
                break;

            case "Empleado":
                manejarEmpleado(request, response, accion);
                break;

            case "Cliente":
                manejarCliente(request, response, accion);
                break;

            case "Producto":
                manejarProducto(request, response, accion);
                break;

            case "Nueva Venta":
                manejarVenta(request, response, accion);
                break;

            case "Laboratorio": // Añadido para Laboratorio
                manejarLaboratorio(request, response, accion);
                break;

            default:
                response.sendError(HttpServletResponse.SC_BAD_REQUEST, "Menú no válido.");
                break;
        }
    }

    private void mostrarPrincipal(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        request.getRequestDispatcher("Principal.jsp").forward(request, response);
    }

    private void manejarEmpleado(HttpServletRequest request, HttpServletResponse response, String accion) throws ServletException, IOException {
        switch (accion) {
            case "Listar":
                listarEmpleados(request, response);
                break;

            case "Agregar":
                agregarEmpleado(request, response);
                break;

            case "Editar":
                editarEmpleado(request, response);
                break;

            case "Actualizar":
                actualizarEmpleado(request, response);
                break;

            case "Eliminar":
                eliminarEmpleado(request, response);
                break;

            default:
                response.sendError(HttpServletResponse.SC_BAD_REQUEST, "Acción no válida para Empleado.");
        }
    }

    private void listarEmpleados(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        List<Empleado> listaEmpleados = edao.listar();
        request.setAttribute("empleados", listaEmpleados);
        request.getRequestDispatcher("Empleado.jsp").forward(request, response);
    }

    private void agregarEmpleado(HttpServletRequest request, HttpServletResponse response) throws IOException {
        Empleado em = new Empleado();
        em.setDni(request.getParameter("txtDni"));
        em.setNombres(request.getParameter("txtNombres"));
        em.setTel(request.getParameter("txtTel"));
        em.setEstado(request.getParameter("txtEstado"));
        em.setUser(request.getParameter("txtUser"));
        em.setPassword(request.getParameter("txtPassword"));
        edao.agregar(em);
        response.sendRedirect("Controlador?menu=Empleado&accion=Listar");
    }

    private void editarEmpleado(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        int ide = Integer.parseInt(request.getParameter("id"));
        Empleado e = edao.listarId(ide);
        request.setAttribute("Empleado", e);
        request.getRequestDispatcher("EditarEmpleado.jsp").forward(request, response);
    }

    private void actualizarEmpleado(HttpServletRequest request, HttpServletResponse response) throws IOException {
        Empleado em = new Empleado();
        em.setDni(request.getParameter("txtDni"));
        em.setNombres(request.getParameter("txtNombres"));
        em.setTel(request.getParameter("txtTel"));
        em.setEstado(request.getParameter("txtEstado"));
        em.setUser(request.getParameter("txtUser"));
        em.setPassword(request.getParameter("txtPassword"));
        em.setIdEmpleado(Integer.parseInt(request.getParameter("id")));
        edao.actualizar(em);
        response.sendRedirect("Controlador?menu=Empleado&accion=Listar");
    }

    private void eliminarEmpleado(HttpServletRequest request, HttpServletResponse response) throws IOException {
        int ide = Integer.parseInt(request.getParameter("id"));
        edao.eliminar(ide);
        response.sendRedirect("Controlador?menu=Empleado&accion=Listar");
    }

    private void manejarCliente(HttpServletRequest request, HttpServletResponse response, String accion) throws ServletException, IOException {
        switch (accion) {
            case "Agregar":
                agregarCliente(request, response);
                break;

            case "Listar":
                listarClientes(request, response);
                break;

            default:
                response.sendError(HttpServletResponse.SC_BAD_REQUEST, "Acción no válida para Cliente.");
        }
    }

    private void agregarCliente(HttpServletRequest request, HttpServletResponse response) throws IOException {
        Clientes c = new Clientes();
        c.setDni(request.getParameter("txtDni"));
        c.setNombres(request.getParameter("txtNombres"));
        c.setDireccion(request.getParameter("txtDireccion"));
        c.setEstado(request.getParameter("txtEstado"));
        cdao.agregar(c);
        response.sendRedirect("Controlador?menu=Cliente&accion=Listar");
    }

    private void listarClientes(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        List<Clientes> listaClientes = cdao.listar();
        request.setAttribute("clientes", listaClientes);
        request.getRequestDispatcher("Clientes.jsp").forward(request, response);
    }

    private void manejarProducto(HttpServletRequest request, HttpServletResponse response, String accion) throws ServletException, IOException {
        switch (accion) {
            case "Agregar":
                agregarProducto(request, response);
                break;

            case "Actualizar":
                actualizarProducto(request, response);
                break;

            case "Editar":
                editarProducto(request, response);
                break;

            case "Eliminar":
                eliminarProducto(request, response);
                break;

            case "Listar":
                listarProductos(request, response);
                break;

            default:
                response.sendError(HttpServletResponse.SC_BAD_REQUEST, "Acción no válida para Producto.");
        }
    }

    private void listarProductos(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        List<Producto> listaProductos = pdao.listar();
        request.setAttribute("productos", listaProductos);
        request.getRequestDispatcher("Producto.jsp").forward(request, response);
    }

    private void agregarProducto(HttpServletRequest request, HttpServletResponse response) throws IOException {
        Producto p = new Producto();
        p.setIdProducto(Integer.parseInt(request.getParameter("idProducto"))); // Asegúrate de que tu formulario envíe este ID
        p.setNombres(request.getParameter("nombre"));
        p.setPrecio(Double.parseDouble(request.getParameter("precio")));
        p.setStock(Integer.parseInt(request.getParameter("stock")));
        p.setEstado(request.getParameter("estado"));
        pdao.agregar(p);
        response.sendRedirect("Controlador?menu=Producto&accion=Listar");
    }

    private void editarProducto(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        int id = Integer.parseInt(request.getParameter("id"));
        Producto p = pdao.listarId(id);
        request.setAttribute("producto", p);
        request.getRequestDispatcher("EditarProducto.jsp").forward(request, response); // Asegúrate de tener un JSP para editar
    }

    private void actualizarProducto(HttpServletRequest request, HttpServletResponse response) throws IOException {
        Producto p = new Producto();
        p.setIdProducto(Integer.parseInt(request.getParameter("idProducto")));
        p.setNombres(request.getParameter("nombre"));
        p.setPrecio(Double.parseDouble(request.getParameter("precio")));
        p.setStock(Integer.parseInt(request.getParameter("stock")));
        p.setEstado(request.getParameter("estado"));
        pdao.actualizar(p);
        response.sendRedirect("Controlador?menu=Producto&accion=Listar");
    }

    private void eliminarProducto(HttpServletRequest request, HttpServletResponse response) throws IOException {
        int id = Integer.parseInt(request.getParameter("id"));
        pdao.eliminar(id);
        response.sendRedirect("Controlador?menu=Producto&accion=Listar");
    }

    private void manejarVenta(HttpServletRequest request, HttpServletResponse response, String accion) throws ServletException, IOException {
        switch (accion) {
            case "BuscarCliente":
                buscarCliente(request, response);
                break;

            case "BuscarProducto":
                buscarProducto(request, response);
                break;

            case "Agregar":
                agregarProductoAVenta(request, response);
                break;

            case "GenerarVenta":
                generarVenta(request, response);
                break;

            default:
                response.sendError(HttpServletResponse.SC_BAD_REQUEST, "Acción no válida para Venta.");
        }
    }

    private void buscarCliente(HttpServletRequest request, HttpServletResponse response) throws IOException {
        String dni = request.getParameter("txtDniCliente");
        Clientes cliente = cdao.buscar(dni);
        request.getSession().setAttribute("cliente", cliente);
        response.sendRedirect("RegistrarVenta.jsp");
    }

    private void buscarProducto(HttpServletRequest request, HttpServletResponse response) throws IOException {
        String nombre = request.getParameter("txtNombreProducto");
        Producto producto = pdao.buscar(nombre);
        request.getSession().setAttribute("producto", producto);
        response.sendRedirect("RegistrarVenta.jsp");
    }

    private void agregarProductoAVenta(HttpServletRequest request, HttpServletResponse response) throws IOException {
        // Lógica para agregar producto a la venta
        response.sendRedirect("RegistrarVenta.jsp");
    }

    private void generarVenta(HttpServletRequest request, HttpServletResponse response) throws IOException {
        Venta v = new Venta();
        // Lógica para generar la venta
        vdao.generar(v);
        response.sendRedirect("Controlador?menu=Nueva Venta&accion=Listar");
    }

    private void manejarLaboratorio(HttpServletRequest request, HttpServletResponse response, String accion) throws ServletException, IOException {
        switch (accion) {
            case "Agregar":
                agregarLaboratorio(request, response);
                break;

            case "Listar":
                listarLaboratorios(request, response);
                break;

            default:
                response.sendError(HttpServletResponse.SC_BAD_REQUEST, "Acción no válida para Laboratorio.");
        }
    }

    private void agregarLaboratorio(HttpServletRequest request, HttpServletResponse response) throws IOException {
        Laboratorio lab = new Laboratorio();
        lab.setRuc(request.getParameter("txtRUC"));
        lab.setNombre(request.getParameter("txtNombre"));
        lab.setTelefono(request.getParameter("txtTelefono"));
        lab.setDireccion(request.getParameter("txtDireccion"));
        labdao.agregar(lab);
        response.sendRedirect("Controlador?menu=Laboratorio&accion=Listar");
    }

    private void listarLaboratorios(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        List<Laboratorio> listaLaboratorios = labdao.listar();
        request.setAttribute("laboratorios", listaLaboratorios);
        request.getRequestDispatcher("Laboratorio.jsp").forward(request, response);
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    @Override
    public String getServletInfo() {
        return "Short description";
    }

    private void iniciarSesion(HttpServletRequest request, HttpServletResponse response) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
}
