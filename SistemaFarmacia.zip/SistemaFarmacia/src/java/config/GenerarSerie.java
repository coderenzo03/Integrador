package config;

/**
 *
 * @author renzo
 */
public class GenerarSerie {

    public String NumeroSerie(int incrementar) {
        throw new UnsupportedOperationException("Not supported yet.");
    }
    
}
